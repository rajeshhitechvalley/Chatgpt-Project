<?php $__env->startSection('title', 'Games Management'); ?>
<?php $__env->startSection('page-title', 'Games Management'); ?>

<?php $__env->startSection('content'); ?>
<div class="row mb-4">
    <div class="col-md-12">
        <div class="d-flex justify-content-between align-items-center">
            <h2>All Games</h2>
            <a href="<?php echo e(route('games.create')); ?>" class="btn btn-gradient">
                <i class="bi bi-plus-circle"></i> Add New Game
            </a>
        </div>
    </div>
</div>

<!-- Filters -->
<div class="card mb-4">
    <div class="card-body">
        <form action="<?php echo e(route('games.index')); ?>" method="GET" class="row g-3">
            <div class="col-md-4">
                <input type="text" name="search" class="form-control" placeholder="Search games..." value="<?php echo e(request('search')); ?>">
            </div>
            <div class="col-md-3">
                <select name="category" class="form-select">
                    <option value="">All Categories</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($cat); ?>" <?php echo e(request('category') == $cat ? 'selected' : ''); ?>><?php echo e($cat); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-2">
                <select name="status" class="form-select">
                    <option value="">All Status</option>
                    <option value="active" <?php echo e(request('status') == 'active' ? 'selected' : ''); ?>>Active</option>
                    <option value="inactive" <?php echo e(request('status') == 'inactive' ? 'selected' : ''); ?>>Inactive</option>
                </select>
            </div>
            <div class="col-md-3">
                <button type="submit" class="btn btn-primary me-2">
                    <i class="bi bi-search"></i> Search
                </button>
                <a href="<?php echo e(route('games.index')); ?>" class="btn btn-secondary">
                    <i class="bi bi-arrow-clockwise"></i> Reset
                </a>
            </div>
        </form>
    </div>
</div>

<!-- Games Table -->
<div class="card">
    <div class="card-header bg-white">
        <div class="d-flex justify-content-between align-items-center">
            <h5 class="mb-0">Games List (<?php echo e($games->total()); ?>)</h5>
            <button class="btn btn-sm btn-danger" id="bulkDeleteBtn" style="display: none;">
                <i class="bi bi-trash"></i> Delete Selected
            </button>
        </div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th width="50">
                            <input type="checkbox" id="selectAll">
                        </th>
                        <th>Game</th>
                        <th>Category</th>
                        <th>Plays</th>
                        <th>Rating</th>
                        <th>Status</th>
                        <th>Created</th>
                        <th width="200">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <input type="checkbox" class="game-checkbox" value="<?php echo e($game->id); ?>">
                        </td>
                        <td>
                            <div class="d-flex align-items-center gap-2">
                                <div class="game-thumb"><?php echo e($game->icon); ?></div>
                                <div>
                                    <div class="fw-semibold"><?php echo $game->title; ?></div>
                                    <small class="text-muted"><?php echo Str::limit($game->description, 50); ?></small>
                                </div>
                            </div>
                        </td>
                        <td><?php echo e($game->category); ?></td>
                        <td><?php echo e($game->formatted_plays); ?></td>
                        <td>
                            <span class="badge bg-warning text-dark">
                                <i class="bi bi-star-fill"></i> <?php echo e($game->rating); ?>

                            </span>
                        </td>
                        <td>
                            <span class="badge bg-<?php echo e($game->status == 'active' ? 'success' : 'danger'); ?>">
                                <?php echo e(ucfirst($game->status)); ?>

                            </span>
                        </td>
                        <td><?php echo e($game->created_at->format('M d, Y')); ?></td>
                        <td>
                            <div class="btn-group" role="group">
                                <a href="<?php echo e(route('games.edit', $game)); ?>" class="btn btn-sm btn-warning">
                                    <i class="bi bi-pencil"></i>
                                </a>
                                <button type="button" class="btn btn-sm btn-info toggle-status" data-id="<?php echo e($game->id); ?>">
                                    <i class="bi bi-toggle-on"></i>
                                </button>
                                <form action="<?php echo e(route('games.destroy', $game)); ?>" method="POST" class="d-inline delete-form">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-danger">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="8" class="text-center py-5">
                            <i class="bi bi-inbox" style="font-size: 3rem; color: #cbd5e0;"></i>
                            <p class="text-muted mt-2">No games found</p>
                            <a href="<?php echo e(route('games.create')); ?>" class="btn btn-gradient">Add First Game</a>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <div class="mt-4">
            <?php echo e($games->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$(document).ready(function() {
    // Select All Checkboxes
    $('#selectAll').change(function() {
        $('.game-checkbox').prop('checked', this.checked);
        toggleBulkDelete();
    });

    $('.game-checkbox').change(function() {
        toggleBulkDelete();
    });

    function toggleBulkDelete() {
        const checked = $('.game-checkbox:checked').length;
        if (checked > 0) {
            $('#bulkDeleteBtn').show();
        } else {
            $('#bulkDeleteBtn').hide();
        }
    }

    // Bulk Delete
    $('#bulkDeleteBtn').click(function() {
        if (!confirm('Are you sure you want to delete selected games?')) return;

        const ids = $('.game-checkbox:checked').map(function() {
            return $(this).val();
        }).get();

        $.post('<?php echo e(route("games.bulk-delete")); ?>', { ids: ids })
            .done(function(response) {
                location.reload();
            });
    });

    // Toggle Status
    $('.toggle-status').click(function() {
        const gameId = $(this).data('id');
        $.post(`/admin/games/${gameId}/toggle-status`)
            .done(function(response) {
                location.reload();
            });
    });

    // Delete Confirmation
    $('.delete-form').submit(function(e) {
        if (!confirm('Are you sure you want to delete this game?')) {
            e.preventDefault();
        }
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\Laravel Projects\Chatgpt-Project\resources\views/admin/games/index.blade.php ENDPATH**/ ?>