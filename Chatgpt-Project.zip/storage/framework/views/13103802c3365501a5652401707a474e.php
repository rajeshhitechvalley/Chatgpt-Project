<?php $__env->startSection('title', 'Add New Game'); ?>
<?php $__env->startSection('page-title', 'Add New Game'); ?>

	    <script src="https://cdn.ckeditor.com/4.21.0/standard/ckeditor.js"></script>

	<!--  -->
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-10 mx-auto">
        
        <div class="card shadow-sm">
            
            <div class="card-header bg-gradient-primary text-white">
                <div class="d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">
                        <i class="bi bi-plus-circle-fill"></i> Create New Game
                    </h5>
                    <a href="<?php echo e(route('games.index')); ?>" class="btn btn-sm btn-light">
                        <i class="bi bi-arrow-left"></i> Back to Games
                    </a>
                </div>
            </div>

            
            <div class="card-body p-4">
                
                <form action="<?php echo e(route('games.store')); ?>" method="POST" enctype="multipart/form-data" id="createGameForm">
                    <?php echo csrf_field(); ?> 

                    
                    <div class="border-bottom pb-3 mb-4">
                        <h6 class="text-primary fw-bold mb-3">
                            <i class="bi bi-info-circle"></i> Basic Information
                        </h6>

                        <div class="row">
                            
                            <div class="col-md-2">
                                <div class="mb-3">
                                    <label class="form-label">
                                        Icon <span class="text-danger">*</span>
                                    </label>

                                    <select name="icon"
                                        class="form-select form-select-lg text-center <?php $__errorArgs = ['icon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        style="font-size: 2rem;">

                                        <option value="">Select</option>

                                        <option value="🧟" <?php echo e(old('icon') == '🧟' ? 'selected' : ''); ?>>🧟</option>
                                        <option value="🏈" <?php echo e(old('icon') == '🏈' ? 'selected' : ''); ?>>🏈</option>
                                        <option value="🍉" <?php echo e(old('icon') == '🍉' ? 'selected' : ''); ?>>🍉</option>
                                        <option value="⛏️" <?php echo e(old('icon') == '⛏️' ? 'selected' : ''); ?>>⛏️</option>
                                        <option value="🎯" <?php echo e(old('icon') == '🎯' ? 'selected' : ''); ?>>🎯</option>
                                        <option value="🏎️" <?php echo e(old('icon') == '🏎️' ? 'selected' : ''); ?>>🏎️</option>
                                        <option value="🗡️" <?php echo e(old('icon') == '🗡️' ? 'selected' : ''); ?>>🗡️</option>
                                        <option value="🧩" <?php echo e(old('icon') == '🧩' ? 'selected' : ''); ?>>🧩</option>
                                        <option value="⚔️" <?php echo e(old('icon') == '⚔️' ? 'selected' : ''); ?>>⚔️</option>
                                        <option value="🏀" <?php echo e(old('icon') == '🏀' ? 'selected' : ''); ?>>🏀</option>

                                        <!-- Default -->
                                        <option value="🎮" <?php echo e(old('icon', '🎮') == '🎮' ? 'selected' : ''); ?>>🎮</option>

                                    </select>

                                    <?php $__errorArgs = ['icon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>


                            
                            <div class="col-md-10">
                                <div class="mb-3">
                                    <label class="form-label fw-semibold">
                                        Game Title
                                        <span class="text-danger">*</span>
                                    </label>
                                    <input
                                        type="text"
                                        name="title"
                                        class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        value="<?php echo e(old('title')); ?>"
                                        placeholder="Enter game title (e.g., Super Mario Bros)"
                                        required
                                        maxlength="255">

                                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    <small class="text-muted">Enter a unique and descriptive title</small>
                                </div>

                                
                                <div class="mb-3">
                                    <label class="form-label fw-semibold">URL Slug (Auto-generated)</label>
                                    <input
                                        type="text"
                                        class="form-control bg-light"
                                        id="slugPreview"
                                        readonly
                                        placeholder="super-mario-bros">
                                    <small class="text-muted">This will be auto-generated from the title</small>
                                </div>
                            </div>
                        </div>
                    </div>

                    
                    <div class="border-bottom pb-3 mb-4">
                        <h6 class="text-primary fw-bold mb-3">
                            <i class="bi bi-gear-fill"></i> Game Details
                        </h6>

                        <div class="row">
                            
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label fw-semibold">
                                        Category
                                        <span class="text-danger">*</span>
                                    </label>
                                    <select
                                        name="category"
                                        class="form-select <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        required>
                                        <option value="">-- Select Category --</option>
                                        <option value="Featured" <?php echo e(old('category') == 'Featured' ? 'selected' : ''); ?>>⚔️ Featured Game</option>
                                        <option value="Action" <?php echo e(old('category') == 'Action' ? 'selected' : ''); ?>>⚔️ Action</option>
                                        <option value="New" <?php echo e(old('category') == 'New' ? 'selected' : ''); ?>>🗺️ New Game</option>
                                        <option value="Adventure" <?php echo e(old('category') == 'Adventure' ? 'selected' : ''); ?>>🗺️ Adventure</option>
                                        <option value="Popular" <?php echo e(old('category') == 'Popular' ? 'selected' : ''); ?>>🧩 Popular Game</option>
                                        <option value="Puzzle" <?php echo e(old('category') == 'Puzzle' ? 'selected' : ''); ?>>🧩 Puzzle</option>
                                        <option value="Original" <?php echo e(old('category') == 'Original' ? 'selected' : ''); ?>>🧩 Original Game</option>
                                        <option value="Updated" <?php echo e(old('category') == 'Updated' ? 'selected' : ''); ?>>🧩 Updated Game</option>
                                        <option value="Sports" <?php echo e(old('category') == 'Sports' ? 'selected' : ''); ?>>⚽ Sports</option>
                                        <option value="Racing" <?php echo e(old('category') == 'Racing' ? 'selected' : ''); ?>>🏎️ Racing</option>
                                        <option value="Basketball" <?php echo e(old('category') == 'Basketball' ? 'selected' : ''); ?>>🏀 Basketball</option>
                                        <option value="Strategy" <?php echo e(old('category') == 'Strategy' ? 'selected' : ''); ?>>🎯 Strategy</option>
                                        <option value="Soccer" <?php echo e(old('category') == 'Soccer' ? 'selected' : ''); ?>>⚾ Soccer</option>
                                        <option value="Escape" <?php echo e(old('category') == 'Escape' ? 'selected' : ''); ?>> 🚪 Escape</option>
                                        <option value="Controller" <?php echo e(old('category') == 'Controller' ? 'selected' : ''); ?>>🎮 Controller</option>
                                        <option value="Bike" <?php echo e(old('category') == 'Bike' ? 'selected' : ''); ?>>🏍 Bike</option>
                                        <option value="Clicker" <?php echo e(old('category') == 'Clicker' ? 'selected' : ''); ?>>👆 Clicker</option>
                                        <option value="Car" <?php echo e(old('category') == 'Car' ? 'selected' : ''); ?>> 🚗 Car</option>
                                        <option value="Driving" <?php echo e(old('category') == 'Driving' ? 'selected' : ''); ?>> 🚗 Driving</option>
                                        <option value="Card" <?php echo e(old('category') == 'Card' ? 'selected' : ''); ?>> 🃏 Card</option>
                                        <option value="Casual" <?php echo e(old('category') == 'Casual' ? 'selected' : ''); ?>>🎲 Casual</option>
                                        <option value="Comet" <?php echo e(old('category') == 'Comet' ? 'selected' : ''); ?>>🗡️ Comet</option>
                                        <option value="RPG" <?php echo e(old('category') == 'RPG' ? 'selected' : ''); ?>>🗡️ RPG</option>
                                        <option value="Shooting" <?php echo e(old('category') == 'Shooting' ? 'selected' : ''); ?>>🔫 Shooting</option>
                                        <option value="Fighting" <?php echo e(old('category') == 'Fighting' ? 'selected' : ''); ?>>🥊 Fighting</option>
                                        <option value="Simulation" <?php echo e(old('category') == 'Simulation' ? 'selected' : ''); ?>>✈️ Simulation</option>
                                        <option value="Multiplayer" <?php echo e(old('category') == 'Multiplayer' ? 'selected' : ''); ?>>👥 Multiplayer</option>
                                    </select>

                                    <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label fw-semibold">
                                        Status
                                        <span class="text-danger">*</span>
                                    </label>
                                    <select
                                        name="status"
                                        class="form-select <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        required>
                                        <option value="active" <?php echo e(old('status', 'active') == 'active' ? 'selected' : ''); ?>>
                                            ✅ Active (Visible to users)
                                        </option>
                                        <option value="inactive" <?php echo e(old('status') == 'inactive' ? 'selected' : ''); ?>>
                                            ❌ Inactive (Hidden from users)
                                        </option>
                                    </select>

                                    <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>

                        
                        <div class="mb-3" >
                            <label class="form-label fw-semibold">
                                Game Description
                            </label>
                            <textarea id="editor"
                                name="description"
                                class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                rows="4"
                                placeholder="Write a detailed description about the game..."
                                maxlength="1000"><?php echo e(old('description')); ?> </textarea>

                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            <small class="text-muted">
                                <span id="charCount">0</span>/1000 characters
                            </small>
                        </div>
                    </div>

                    
                    <div class="border-bottom pb-3 mb-4">
                        <h6 class="text-primary fw-bold mb-3">
                            <i class="bi bi-graph-up"></i> Game Statistics
                        </h6>

                        <div class="row">
                            
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label class="form-label fw-semibold">
                                        Number of Plays
                                    </label>
                                    <input
                                        type="number"
                                        name="plays"
                                        class="form-control <?php $__errorArgs = ['plays'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        value="<?php echo e(old('plays', 0)); ?>"
                                        min="0"
                                        step="1"
                                        placeholder="0">

                                    <?php $__errorArgs = ['plays'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    <small class="text-muted">Initial play count (default: 0)</small>
                                </div>
                            </div>

                            
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label class="form-label fw-semibold">
                                        Rating (1-5 stars)
                                    </label>
                                    <div class="input-group">
                                        <span class="input-group-text">⭐</span>
                                        <input
                                            type="number"
                                            name="rating"
                                            class="form-control <?php $__errorArgs = ['rating'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            value="<?php echo e(old('rating', 4.5)); ?>"
                                            step="0.1"
                                            min="1"
                                            max="5"
                                            placeholder="4.5">
                                    </div>

                                    <?php $__errorArgs = ['rating'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    <small class="text-muted">Enter a rating between 1.0 and 5.0</small>
                                </div>
                            </div>

                            
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label class="form-label fw-semibold">
                                        Game Thumbnail
                                    </label>
                                    <input
                                        type="file"
                                        name="thumbnail"
                                        class="form-control <?php $__errorArgs = ['thumbnail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        accept="image/jpeg,image/png,image/jpg,image/gif,image/webp"
                                        id="thumbnailInput">

                                    <?php $__errorArgs = ['thumbnail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    <small class="text-muted">Max size: 2MB (JPG, PNG, GIF, WEBP)</small>
                                </div>

                                
                                <div id="imagePreview" class="mt-2" style="display: none;">
                                    <img src="" alt="Preview" class="img-thumbnail" style="max-height: 150px;">
                                    <button type="button" class="btn btn-sm btn-danger mt-2" id="removeImage">
                                        <i class="bi bi-trash"></i> Remove
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>

                    
                    <div class="mb-4">
                        <h6 class="text-primary fw-bold mb-3">
                            <i class="bi bi-link-45deg"></i> Additional Information
                        </h6>

                        <div class="mb-3">
                            <label class="form-label fw-semibold">
                                Game URL (Optional)
                            </label>
                            <div class="input-group" >
                                <span class="input-group-text">🌐</span>
                                <input
                                    type="url"
                                    name="url"
                                    class="form-control <?php $__errorArgs = ['url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    value="<?php echo e(old('url')); ?>"
                                    placeholder="https://example.com/game-link"
                                    maxlength="500">
                            </div>

                            <?php $__errorArgs = ['url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            <small class="text-muted">Enter the URL where users can play this game</small>
                        </div>
                    </div>

                    
                    <div class="border-top pt-4">
                        <div class="d-flex gap-2 justify-content-between">
                            
                            <a href="<?php echo e(route('games.index')); ?>" class="btn btn-secondary">
                                <i class="bi bi-x-circle"></i> Cancel
                            </a>

                            <div class="d-flex gap-2">
                                
                                <button type="reset" class="btn btn-outline-warning">
                                    <i class="bi bi-arrow-clockwise"></i> Reset Form
                                </button>

                                
                                <button type="submit" class="btn btn-success btn-lg">
                                    <i class="bi bi-check-circle"></i> Create Game
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        
        <div class="card mt-4 bg-light">
            <div class="card-body">
                <h6 class="fw-bold mb-2">
                    <i class="bi bi-lightbulb text-warning"></i> Tips for Creating Games
                </h6>
                <ul class="mb-0 small">
                    <li>Use descriptive and unique titles for better SEO</li>
                    <li>Choose an appropriate emoji icon that represents the game</li>
                    <li>Write detailed descriptions to help users understand the game</li>
                    <li>Upload high-quality thumbnails (recommended: 16:9 ratio)</li>
                    <li>Set status to "Inactive" if the game is not ready yet</li>
                    <li>Fields marked with <span class="text-danger">*</span> are required</li>
                </ul>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .bg-gradient-primary {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    }

    .form-label {
        font-size: 14px;
        margin-bottom: 6px;
    }

    .card {
        border: none;
        border-radius: 12px;
    }

    .card-header {
        border-radius: 12px 12px 0 0 !important;
    }

    #imagePreview img,
    .img-thumbnail {
        border-radius: 8px;
        border: 1px solid #dee2e6;
        background: #fff;
        max-width: 100%;
        height: auto;
    }

    #imagePreview {
        display: flex;
        flex-direction: column;
        align-items: flex-start;
        gap: 0.5rem;
    }

    #removeImage {
        padding: 0.25rem 0.75rem;
        font-size: 0.9rem;
        border-radius: 6px;
        transition: background 0.2s;
    }

    #removeImage:hover {
        background: #dc3545;
        color: #fff;
    }

    .input-group-text {
        background-color: #f8f9fa;
    }

    .invalid-feedback {
        display: block;
        color: #dc3545;
        font-size: 0.95em;
        margin-top: 0.25rem;
    }

    .form-control.is-invalid,
    .form-select.is-invalid {
        border-color: #dc3545;
        box-shadow: 0 0 0 0.1rem rgba(220, 53, 69, .15);
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function() {

        // ========================================
        // Auto-generate slug from title
        // ========================================
        $('input[name="title"]').on('keyup', function() {
            let title = $(this).val();
            let slug = title.toLowerCase()
                .replace(/[^\w\s-]/g, '') // Remove special characters
                .replace(/\s+/g, '-') // Replace spaces with hyphens
                .replace(/-+/g, '-') // Replace multiple hyphens with single
                .trim();

            $('#slugPreview').val(slug);
        });

        // ========================================
        // Character counter for description
        // ========================================
        $('textarea[name="description"]').on('keyup', function() {
            let count = $(this).val().length;
            $('#charCount').text(count);

            if (count > 900) {
                $('#charCount').addClass('text-danger');
            } else {
                $('#charCount').removeClass('text-danger');
            }
        });

        // ========================================
        // Image preview functionality
        // ========================================
        $('#thumbnailInput').on('change', function(e) {
            let file = e.target.files[0];

            if (file) {
                // Check file size (2MB max)
                if (file.size > 2 * 1024 * 1024) {
                    alert('File size must be less than 2MB!');
                    $(this).val('');
                    return;
                }

                // Show preview
                let reader = new FileReader();
                reader.onload = function(e) {
                    $('#imagePreview img').attr('src', e.target.result);
                    $('#imagePreview').show();
                };
                reader.readAsDataURL(file);
            }
        });

        // Remove image preview
        $('#removeImage').on('click', function() {
            $('#thumbnailInput').val('');
            $('#imagePreview').hide();
        });

        // ========================================
        // Form validation before submit
        // ========================================
        $('#createGameForm').on('submit', function(e) {
            let title = $('input[name="title"]').val().trim();
            let category = $('select[name="category"]').val();
            let icon = $('input[name="icon"]').val().trim();

            // Check if required fields are filled
            if (!title || !category || !icon) {
                e.preventDefault();
                alert('Please fill in all required fields marked with *');
                return false;
            }

            // Confirm submission
            if (!confirm('Are you sure you want to create this game?')) {
                e.preventDefault();
                return false;
            }

            // Show loading state
            $(this).find('button[type="submit"]')
                .html('<i class="bi bi-hourglass-split"></i> Creating...')
                .prop('disabled', true);
        });

        // ========================================
        // Initialize tooltips
        // ========================================
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        var tooltipList = tooltipTriggerList.map(function(tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });

        // ========================================
        // Reset form functionality
        // ========================================
        $('button[type="reset"]').on('click', function() {
            if (confirm('Are you sure you want to reset all fields?')) {
                $('#imagePreview').hide();
                $('#slugPreview').val('');
                $('#charCount').text('0');
            } else {
                return false;
            }
        });
    });
</script>

<script>
    // Activate CKEditor on the textarea
    CKEDITOR.replace('editor');
</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\Laravel Projects\Chatgpt-Project\resources\views/admin/games/create.blade.php ENDPATH**/ ?>