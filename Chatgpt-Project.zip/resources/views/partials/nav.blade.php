   <nav class="nav-section">
       <a href="#" class="nav-item active">
           <span class="nav-icon">🏠</span>
           <span>Home</span>
       </a>

       <a href="#" class="nav-item">
           <span class="nav-icon">✨</span>
           <span>New</span>
       </a>
       <a href="#" class="nav-item">
           <span class="nav-icon">🔥</span>
           <span>Popular Games</span>
       </a>
       <a href="#" class="nav-item">
           <span class="nav-icon">🔄</span>
           <span>Updated</span>
       </a>
       <a href="#" class="nav-item">
           <span class="nav-icon">🎮</span>
           <span>Originals</span>
       </a>
       <a href="#" class="nav-item">
           <span class="nav-icon">👥</span>
           <span>Multiplayer</span>
       </a>
   </nav>
