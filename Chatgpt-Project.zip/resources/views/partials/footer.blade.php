       <footer class="footer">
                <div class="footer-links">
                    <a href="#" class="footer-link">About</a>
                    <a href="#" class="footer-link">Developers</a>
                    <a href="#" class="footer-link">Kids site</a>
                    <a href="#" class="footer-link">Jobs</a>
                    <a href="#" class="footer-link">Terms & conditions</a>
                    <a href="#" class="footer-link">Privacy</a>
                    <a href="#" class="footer-link">All games</a>
                </div>
                <div class="copyright">© 2026 CrazyGames</div>
            </footer>