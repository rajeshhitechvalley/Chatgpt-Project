@foreach($users as $user)
<tr>
  <td>{{ $user->name }}</td>
  <td>{{ $user->role }}</td>
  <td>
    trst
   
  </td>
</tr>
@endforeach
